# expendable
A Firefox extension for single-use bookmarks
